/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package radios;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class MaFenetre extends JFrame implements ActionListener
{
        public MaFenetre(String libelles[])
        {
            setTitle("Boutons Radio");
            setSize(400,160);
            Container contenu= getContentPane();
            boutEtat = new JButton ("Etat");
            boutEtat.addActionListener(this);
            contenu.add(boutEtat, "South");
            
            //les boutons radios dans le panneau
           pan = new JPanel() ;
           contenu.add(pan);
           
           this.libelles=libelles;
           nbBoutons=libelles.length;
           
           ButtonGroup groupe = new ButtonGroup();
           
           boutons= new JRadioButton[nbBoutons];
           for (int i=0; i<nbBoutons ; i++)
           {
               boutons[i]= new JRadioButton(libelles[i]);
               pan.add(boutons[i]);
               groupe.add(boutons[i]);
               boutons[i].addActionListener(this);
               
           }
           if(nbBoutons > 0)
              boutons[0].setSelected(true);    
        }
        
       
        
    @Override
    public void actionPerformed(ActionEvent e)
    {
        Object source =e.getSource();
        if(source==boutEtat)
        {
            System.out.println(" Boutons selectionne ");
            for(int i=0; i<nbBoutons; i++)
             if(boutons[i].isSelected())  
                 System.out.print(libelles[i]+" ");
             System.out.println();
        }
         for(int i=0; i<nbBoutons; i++)
             if(source==boutons[i])
                    System.out.println("Action bouton " + libelles[i]);
    }
   
        private JButton boutEtat, boutdef;
        private JPanel pan ;
        private JRadioButton boutons[];
        private String libelles[]; 
        private int nbBoutons ;
    
    
}

/**
 *
 * @author koivogui
 */
public class Radios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String libelles[]= {"cercles", "Rectangle","Triangle","pentagone","Ellipse","carre"};
        MaFenetre fen = new MaFenetre (libelles);
        fen.setVisible(true);
    }
    
}
