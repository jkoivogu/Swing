/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cochesb;

/**
 *
 * @author koivogui
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class MaFenetre extends JFrame implements ActionListener 
{
    public MaFenetre(String libelles[])
    {
        setTitle("Cases a cocher ");
        setSize(400,160);
        Container contenu = getContentPane();
        
        // les deux boutons 
        
        boutRaz = new JButton("RAZ");
        boutRaz.addActionListener(this);
        contenu.add(boutRaz, "North");
        
        boutEtat = new JButton("Etat");
        boutEtat.addActionListener(this);
        contenu.add(boutEtat, "South");
        
        // les cases a cocher dans le panneau
        
        pan = new JPanel();
        contenu.add(pan);
        this.libelles = libelles;
        nbCases =libelles.length;
        
        cases = new JCheckBox[nbCases];
        for(int i=0 ; i<nbCases; i++)
        {
            cases[i]=new JCheckBox(libelles[i]);
            pan.add(cases[i]);
            cases[i].addActionListener(this);
//            cases[i].addItemListener((ItemListener) this);
                    
        }
           
    }
    
    private JCheckBox cases [];
    private JButton boutRaz , boutEtat; 
    private JPanel pan ;
    private int nbCases;
    private String libelles[];
    
    @Override
    public void actionPerformed(ActionEvent e) 
    { Object source =e.getSource();
      if(source==boutRaz)
        for(int i=0 ; i<nbCases; i++)
          cases[i].setSelected(false);
      if(source==boutEtat)
      {
          System.out.print("Cases Selectionnees : ");
           for(int i=0 ; i<nbCases; i++)
               if(cases[i].isSelected())
                   System.out.print(libelles[i]+ " ");
           System.out.println();
      }
      for(int i=0 ; i<nbCases; i++)
               if(source==cases[i])
                   System.out.println("Action case " + libelles[i]);
    }
   public void itemstateChanged (ItemEvent e)
   {     Object source =e.getSource();
         for(int i=0 ; i<nbCases; i++)
               if(source==cases[i])
                   System.out.println("Item case " + libelles[i]);
   }
}

public class Cochesb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
        String libelles[] = {"Cercle","Rectangle","Triangle", "Pentagone", "ellipse","carre"} ;
        MaFenetre fen = new MaFenetre(libelles);
        fen.setVisible(true);
    }
    
}
